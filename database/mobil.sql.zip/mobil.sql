-- phpMyAdmin SQL Dump
-- version 3.2.0.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jun 22, 2017 at 05:39 PM
-- Server version: 5.1.37
-- PHP Version: 5.3.0

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `mobil`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE IF NOT EXISTS `admin` (
  `id_admin` int(11) NOT NULL AUTO_INCREMENT,
  `user` varchar(30) NOT NULL,
  `pass` varchar(32) NOT NULL,
  PRIMARY KEY (`id_admin`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id_admin`, `user`, `pass`) VALUES
(1, 'admin', '21232f297a57a5a743894a0e4a801fc3');

-- --------------------------------------------------------

--
-- Table structure for table `bayar_cicilan`
--

CREATE TABLE IF NOT EXISTS `bayar_cicilan` (
  `kode_cicilan` int(11) NOT NULL AUTO_INCREMENT,
  `kode_kredit` int(11) NOT NULL,
  `tgl_cicilan` date NOT NULL,
  `jumlah_cicilan` int(11) NOT NULL,
  `cicilan_ke` int(11) NOT NULL,
  `cicilan_sisa_ke` int(11) NOT NULL,
  `cicilan_sisa_harga` int(11) NOT NULL,
  PRIMARY KEY (`kode_cicilan`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `bayar_cicilan`
--


-- --------------------------------------------------------

--
-- Table structure for table `beli_cash`
--

CREATE TABLE IF NOT EXISTS `beli_cash` (
  `kode_cash` int(20) NOT NULL AUTO_INCREMENT,
  `kode_mobil` int(12) NOT NULL,
  `cash_tanggal` date NOT NULL,
  `cash_bayar` int(20) NOT NULL,
  `cash_kembalian` int(20) NOT NULL,
  `id` int(11) NOT NULL,
  `status` varchar(30) NOT NULL,
  PRIMARY KEY (`kode_cash`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=13 ;

--
-- Dumping data for table `beli_cash`
--

INSERT INTO `beli_cash` (`kode_cash`, `kode_mobil`, `cash_tanggal`, `cash_bayar`, `cash_kembalian`, `id`, `status`) VALUES
(1, 8, '2016-12-06', 200000000, 50000000, 3, 'Masih Di Proses'),
(2, 7, '2016-12-07', 100000000, 0, 7, 'Berhasil'),
(3, 10, '2016-12-07', 500000000, 0, 7, 'Masih Di Proses'),
(4, 7, '2016-12-07', 100000000, 0, 2, 'Masih Di Proses'),
(6, 8, '2016-12-08', 155000000, 5000000, 9, 'Berhasil'),
(5, 18, '2016-12-07', 500000000, 29000000, 3, 'Masih Di Proses'),
(7, 11, '2016-12-10', 130000000, 5000000, 2, 'Berhasil'),
(8, 10, '2017-01-29', 550000000, 50000000, 6, 'Masih Di Proses'),
(9, 9, '2017-03-07', 120000000, 0, 10, 'Masih Di Proses'),
(10, 12, '2017-03-07', 500000000, 51000000, 10, 'Masih Di Proses'),
(11, 20, '2017-05-20', 700000000, 12000000, 11, 'Berhasil'),
(12, 19, '2017-05-20', 400000000, 2000000, 11, 'Masih Di Proses');

-- --------------------------------------------------------

--
-- Table structure for table `kredit`
--

CREATE TABLE IF NOT EXISTS `kredit` (
  `kode_kredit` int(11) NOT NULL AUTO_INCREMENT,
  `id` int(11) NOT NULL,
  `kode_paket` int(11) NOT NULL,
  `kode_mobil` int(11) NOT NULL,
  `tgl_kredit` date NOT NULL,
  `fotocopy_ktp` text NOT NULL,
  `fotocopy_kk` text NOT NULL,
  `fotocopy_slipgaji` text NOT NULL,
  PRIMARY KEY (`kode_kredit`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `kredit`
--


-- --------------------------------------------------------

--
-- Table structure for table `mobil`
--

CREATE TABLE IF NOT EXISTS `mobil` (
  `kode_mobil` int(12) NOT NULL AUTO_INCREMENT,
  `merk` varchar(30) NOT NULL,
  `tipe` varchar(30) NOT NULL,
  `harga_mobil` int(11) NOT NULL,
  `gambar` varchar(200) NOT NULL,
  PRIMARY KEY (`kode_mobil`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=21 ;

--
-- Dumping data for table `mobil`
--

INSERT INTO `mobil` (`kode_mobil`, `merk`, `tipe`, `harga_mobil`, `gambar`) VALUES
(6, 'Jeep', 'Mobil Sport', 120000000, 'Dodge Viper SRT 10.jpg'),
(5, 'Ford', 'Mobil Sport', 100000000, 'Nissan_Skyline_R33_GT-R.jpg'),
(7, 'Kijang Inova', 'Mobil Keluarga', 100000000, 'Nissan-Fairlady-Z-350Z.jpg'),
(8, 'Toyota M3', 'Mobil Keluarga', 150000000, '2000-acura-nsx-3.jpg'),
(9, 'Chevorlet', 'Mobil Keluarga', 120000000, 'toyota_gt86.jpg'),
(10, 'Shelby Cobra', 'Mobil Keluarga', 500000000, 'Dodge Viper SRT 10.jpg'),
(11, 'Avanza Z3', 'Mobil Keluarga', 125000000, 'Honda-Integra-JDM-Crystal-Blue-Fire-City-Car-2014-HD-Wallpapers-design-by-Tony-Kokhan-www.el-tony.com_.jpg'),
(12, 'Toyota Casher', 'Mobil Keluarga', 449000000, 'Toyota-Chaser-JZX100-JDM-Crystal-City-Drift-Plastic-Smoke-Car-2014-Azure-Neon-HD-Wallpapers-design-by-Tony-Kokhan-www.el-tony.com_.jpg'),
(13, 'Nissan Skyline R', 'Mobil Sport', 798000000, 'Toyota-Chaser-JZX100-JDM-Crystal-City-Drift-Plastic-Smoke-Car-2014-Azure-Neon-HD-Wallpapers-design-by-Tony-Kokhan-www.el-tony.com_.jpg'),
(14, 'AE86 Trueno', 'Mobil Sport', 598000000, 'AE86 Trueno.jpg'),
(15, 'Lamborghini Diablo', 'Mobil Sport', 1089000000, 'lamborghini_diablo_vt_titanium_rear2.jpg'),
(16, 'Toyota GT 86', 'Mobil Sport', 998000000, 'toyota_gt86.jpg'),
(17, 'Nissan 370Z', 'Mobil Keluarga', 879000000, 'Nissan-370Z-JDM-Crystal-City-Smoke-Drift-Car-2014-Art-Violet-Neon-HD-Wallpapers-design-by-Tony-Kokhan-www.el-tony.com_.jpg'),
(18, 'Nissa Fair Lady Z', 'Mobil Keluarga', 471000000, 'modp_1012_03_o+1974_nissan_fairlady_z+rear_view.jpg'),
(19, 'Subaru Impreza', 'Mobil Keluarga', 398000000, '2011-subaru-impreza-wrx-sti-sedan.jpg'),
(20, 'Nissan Silvia', 'Mobil Keluarga', 688000000, 'Nissan-Silvia-S15-JDM-Crystal-City-Drift-Smoke-Car-2014-Azure-Neon-HD-Wallpapers-design-by-Tony-Kokhan-www.el-tony.com_.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `paket_kredit`
--

CREATE TABLE IF NOT EXISTS `paket_kredit` (
  `id_paket_kredit` int(40) NOT NULL AUTO_INCREMENT,
  `id_mobil` int(40) NOT NULL,
  `id_pembeli` int(40) NOT NULL,
  `uang_muka` int(40) NOT NULL,
  `angsuran` int(40) NOT NULL,
  `bulan` int(40) NOT NULL,
  `tanggal` date NOT NULL,
  PRIMARY KEY (`id_paket_kredit`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `paket_kredit`
--

INSERT INTO `paket_kredit` (`id_paket_kredit`, `id_mobil`, `id_pembeli`, `uang_muka`, `angsuran`, `bulan`, `tanggal`) VALUES
(1, 11, 7, 25000000, 9000000, 11, '2016-12-09'),
(3, 16, 6, 199600000, 39920000, 24, '2017-01-28'),
(4, 14, 6, 119600000, 15548000, 48, '2017-01-29');

-- --------------------------------------------------------

--
-- Table structure for table `pembeli`
--

CREATE TABLE IF NOT EXISTS `pembeli` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ktp` varchar(20) NOT NULL,
  `nama_pembeli` varchar(50) NOT NULL,
  `alamat` text NOT NULL,
  `telp` varchar(12) NOT NULL,
  `password` varchar(15) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=12 ;

--
-- Dumping data for table `pembeli`
--

INSERT INTO `pembeli` (`id`, `ktp`, `nama_pembeli`, `alamat`, `telp`, `password`) VALUES
(2, '9012039018013801', 'Bahrudin Nur Amin', 'Mojokerto', '082998293019', 'amin'),
(3, '9012039018013801', 'Geri Adam Saputra', 'Surabaya', '081559965998', 'geri'),
(5, '9012039018013802', 'Livia Andi', 'Jombang', '083929482942', 'andi'),
(6, '9012039018013800', 'Fajar Abidin', 'Jombang', '081559965980', 'fajar'),
(7, '9012039018013800', 'Ahmad Andre', 'Jombang', '081272009854', 'andre'),
(8, '9012039018013809', 'Hasanudin Amir', 'Mojokerto', '085745747196', 'hasan'),
(9, '123', 'anas', 'bancang', '098765432123', 'anas'),
(10, '29103894814081034', 'Anas', 'Jombang', '081234567890', 'anas'),
(11, '1', 'g', 'g', '1234567890', 'geriadam');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
